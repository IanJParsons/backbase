package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoadWebsite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 WebDriver driver = new FirefoxDriver();
 
 //Set homepage URL
 String sHome = "http://computer-database.herokuapp.com/computers";
 String sTarget = "http://computer-database.herokuapp.com/computers/new";
 driver.get(sHome);
 
 //Wait for page to load
 try {
	Thread.sleep(5000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
 //Define Add Computer button as element
 WebElement bAddNew = driver.findElement(By.id("add"));
 //Click Add a new computer button
 bAddNew.click();
 
 //Check current URL matches the target (Add computer page)
 String sURL = driver.getCurrentUrl();
 
 if (sURL.equals(sTarget)){
		System.out.println("Verification Successful - The correct page is opened.");
	}else{
		System.out.println("Verification Failed - New Computer page has not been opened.");
		System.out.println("Actual URL is : " + sURL);
		System.out.println("Expected URL is : " + sTarget);
	}
 
 
 
 
	}

}
